class Wind {
  constructor() {
    this.r = 40;
    this.t = 100;
    this.x = character.x + 600;
    this.y = mouseY;
  }
  
  move() {
    this.x -= 3;
  }
  
  show() {
    image(pImg, this.x, mouseY, this.r, this.t);
    //rect(this.x, this.y, this.r, this.r);
  }
  
  
  
}
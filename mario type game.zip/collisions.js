class Collision {
  constructor() {
    this.r = 80;
    this.x = 250;
    this.y = 240;
    this.t = 165;
  }
  move() {}
  show() {
    //image(bImg, this.x, this.y, this.r, this.r);
    image(bImg, 250, this.y, this.r, this.r);
  }
}

class Collision2 {
  constructor() {
    this.r = 80;
    this.x = 600;
    this.y = 240;
    this.t = 165;
  }
  move() {}
  show() {
    //image(bImg, this.x, this.y, this.r, this.r);
    image(bImg, 950, this.y, this.r, this.r);
  }
}

class Collision3 {
  constructor() {
    this.r = 80;
    this.x = 950;
    this.y = 240;
    this.t = 165;
  }
  move() {}
  show() {
    //image(bImg, this.x, this.y, this.r, this.r);
    image(bImg, 950, this.y, this.r, this.r);
  }
}

class Collision4 {
  constructor() {
    this.r = 80;
    this.x = 1250;
    this.y = 240;
    this.t = 165;
  }
  move() {}
  show() {
    //image(bImg, this.x, this.y, this.r, this.r);
    image(bImg, 1250, this.y, this.r, this.r);
  }
}

class Collision5 {
  constructor() {
    this.r = 80;
    this.x = 1600;
    this.y = 240;
    this.t = 165;
  }
  move() {}
  show() {
    //image(bImg, this.x, this.y, this.r, this.r);
    image(bImg, 1600, this.y, this.r, this.r);
  }
}

class Collision6 {
  constructor() {
    this.r = 80;
    this.x = 1950;
    this.y = 240;
    this.t = 165;
  }
  move() {}
  show() {
    //image(bImg, this.x, this.y, this.r, this.r);
    image(bImg, 1950, this.y, this.r, this.r);
  }
}

class Collision7 {
  constructor() {
    this.r = 80;
    this.x = 2250;
    this.y = 240;
    this.t = 165;
  }
  move() {}
  show() {
    //image(bImg, this.x, this.y, this.r, this.r);
    image(bImg, 2250, this.y, this.r, this.r);
  }
}

class Collision8 {
  constructor() {
    this.r = 80;
    this.x = 2500;
    this.y = 240;
    this.t = 165;
  }
  move() {}
  show() {
    //image(bImg, this.x, this.y, this.r, this.r);
    image(bImg, 2500, this.y, this.r, this.r);
  }
}

class Collision9 {
  constructor() {
    this.r = 80;
    this.x = 2950;
    this.y = 240;
    this.t = 165;
  }
  move() {}
  show() {
    //image(bImg, this.x, this.y, this.r, this.r);
    image(bImg, 2950, this.y, this.r, this.r);
  }
}

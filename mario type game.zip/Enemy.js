class Enemy {
  constructor() {
    this.r = 50;
    this.x = character.x + 600;
    this.y = 255;
  }
  
  move() {
    this.x -= 6;
  }
  
  show() {
    image(cImg, this.x, this.y, this.r, this.r);
    //rect(this.x, this.y, this.r, this.r);
  }
  
  
  
}
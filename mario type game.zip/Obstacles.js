class Obstacle {
  constructor() {
    this.r = 50;
    this.x = character.x + 600;
    this.y = 285;
  }
  

  move() {
  
  }
  
  show() {
    image(bImg, this.x, this.y, this.r, this.r);
 
    image(bImg, 250, this.y, this.r, this.r);
    image(bImg, 600, this.y, this.r, this.r);
    image(bImg, 150, this.y, this.r, this.r);
  }
  
  
}
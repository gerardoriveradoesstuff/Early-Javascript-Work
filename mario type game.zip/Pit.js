class Pit {
  constructor() {
    this.r = 80;
    this.h = 30;
    this.x = 1520;
    this.y = 290;
  }

  show() {
    //image(bImg, this.x, this.y, this.r, this.r);
    image(gImg, this.x, this.y, this.r, this.h);
  }
}

class Pit2 {
  constructor() {
    this.r = 80;
    this.h = 30;
    this.x = 350;
    this.y = 300;
  }

  show() {
    //image(bImg, this.x, this.y, this.r, this.r);
    image(gImg, this.x, this.y, this.r, this.h);
  }
}

let character;
let uImg;
let tImg;
let bImg;
let cImg;
let dImg;
let enemy = [];
let obstacle = [];
let testobs = [];
let walls = [];
let wind = [];
let collision = [];
let collision2 = [];
let collision3 = [];
let collision4 = [];
let collision5 = [];
let collision6 = [];
let collision7 = [];
let collision8 = [];
let collision9 = [];
let cloud = [];
let pit = [];
let pit2 = [];

function preload() {
  uImg = loadImage("back.png");
  tImg = loadImage("Enemie.gif");
  lImg = loadImage("cloud.gif");
  bImg = loadImage("obs.png");
  cImg = loadImage("op.gif");
  dImg = loadImage("wall.png");
  pImg = loadImage("wind.png");
  gImg = loadImage("pit.png");
  bmusic = loadSound("bm.mp3")
}
function setup() {
  createCanvas(600, 450);
  character = new Character();
  bmusic.play();
  bmusic.setVolume(0.25);
  bmusic.rate(1.4);
}

function keyPressed() {
  if (key == "w") {
    character.jump();
  }
  if (key == "d") {
    character.forward();
  }
  if (key == "a") {
    character.back();
  }
}

function draw() {
  if (random(1) < 0.024) {
    enemy.push(new Enemy());
  }

  if (random(1) < 0.005) {
    cloud.push(new Cloud());
  }

  if (random(1) < 0.0036) {
    walls.push(new Walls());
  }

  if (random(1) < 0.0016) {
    wind.push(new Wind());
  }

  collision.push(new Collision());

  collision2.push(new Collision2());

  collision3.push(new Collision3());

  collision4.push(new Collision4());

  collision5.push(new Collision5());

  collision6.push(new Collision6());

  collision7.push(new Collision7());

  collision8.push(new Collision8());

  collision9.push(new Collision9());

  testobs.push(new Testobs());

  pit.push(new Pit());
  
  pit2.push(new Pit2());

  background(uImg);

  
  if (key == "d") {
    translate(-character.x, 0);
  } 
  if (key == "w") {
    translate(-character.x, 0);
  } 
  if (key == "a") {
    translate(-character.x, 0);
  } 
  
  
  for (let l of cloud) {
    l.move();
    l.show();
    if (character.hits(l)) {
      console.log("On top of cloud");
      character.y = 120;
    }
  }

  for (let b of testobs) {
    b.show();
    if (character.hits(b)) {
      console.log("On top of pipe");
      character.y = height - character.y;
    }
  }
  for (let h of collision) {
    h.show();
    if (character.hits(h)) {
      fill(200);
      console.log("On top of pipe");
      character.y = 170;
    }
  }

  for (let v of collision2) {
    v.show();
    if (character.hits(v)) {
      fill(200);
      console.log("On top of pipe");
      character.y = 170;
    }
  }

  for (let j of collision3) {
    j.show();
    if (character.hits(j)) {
      fill(200);
      console.log("On top of pipe");
      character.y = 170;
    }
  }

  for (let r of collision4) {
    r.show();
    if (character.hits(r)) {
      fill(200);
      console.log("On top of pipe");
      character.y = 170;
    }
  }

  for (let m of collision5) {
    m.show();
    if (character.hits(m)) {
      fill(200);
      console.log("On top of pipe");
      character.y = 170;
    }
  }

  for (let i of collision6) {
    i.show();
    if (character.hits(i)) {
      fill(200);
      console.log("On top of pipe");
      character.y = 170;
    }
  }

  for (let o of collision7) {
    o.show();
    if (character.hits(o)) {
      fill(200);
      console.log("On top of pipe");
      character.y = 170;
    }
  }

  for (let q of collision8) {
    q.show();
    if (character.hits(q)) {
      fill(200);
      console.log("On top of pipe");
      character.y = 170;
    }
  }

  for (let f of collision9) {
    f.show();
    if (character.hits(f)) {
      fill(200);
      console.log("On top of pipe");
      character.y = 170;
    }
  }

  for (let t of enemy) {
    t.move();
    t.show();
    if (character.hits(t)) {
      console.log("game over");
      noLoop();
      bmusic.setVolume(0.1);
      bmusic.rate(0.3);
    }
  }

  for (let m of pit) {
    m.show();
    if (character.hits(m)) {
      console.log("game over");
      noLoop();
      bmusic.setVolume(0);
      bmusic.rate(0.3);
    }
  }

  for (let u of pit2) {
    u.show();
    if (character.hits(u)) {
      console.log("game over");
      noLoop();
      bmusic.setVolume(0);
      bmusic.rate(0.3);
    }
  }
  
  
  for (let d of walls) {
    d.move();
    d.show();
    if (character.hits(d)) {
      console.log("game over");
      noLoop();
      character.vx = character.vx - 2;
      bmusic.setVolume(0);
      bmusic.rate(0.3);
    }
  }

  for (let p of wind) {
    p.move();
    p.show();
    if (character.hits(p)) {
      // console.log('game over');
      // noLoop();
      character.x = character.x - 20;
    }
  }

  character.show();
  character.move();
  
  
  
}

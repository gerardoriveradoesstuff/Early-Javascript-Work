class Testobs {
  constructor() {
    this.r = 80;
    this.x = width;
    this.y = 240;
    this.t = 165;
  }

  move() {}

  show() {
    //image(bImg, this.x, this.y, this.r, this.r);

    image(bImg, 250, this.y, this.r, this.r);
    image(bImg, 600, this.y, this.r, this.r);
    image(bImg, 950, this.y, this.r, this.r);
    image(bImg, 1250, this.y, this.r, this.r);
    image(bImg, 1600, this.y, this.r, this.r);
    image(bImg, 1950, this.y, this.r, this.r);
    image(bImg, 2250, this.y, this.r, this.r);
    image(bImg, 2500, this.y, this.r, this.r);
    image(bImg, 2950, this.y, this.r, this.r);
  }
}

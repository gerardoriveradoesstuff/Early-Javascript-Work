class Character {
  constructor() {
    this.r = 70;
    this.x = 150;
    this.y = 250;
    this.vy = 0;
    this.vx = 0;
    this.gravity = 0.35;
    this.for = 0.1;
  }

  forward() {
    this.x = this.x + 40;
    
  }

  back() {
    this.x = this.x - 40;
  }

  jump() {
    if (this.y >= 150) {
      this.vy = -10;
    }
  }

  hits(enemy) {
    return collideRectRect(
      this.x,
      this.y,
      this.r,
      this.r,
      enemy.x,
      enemy.y,
      enemy.r,
      enemy.r
    );
  }

  hits(testobs) {
    return collideRectRect(
      this.x,
      this.y,
      this.r,
      this.r,
      testobs.x,
      testobs.y,
      testobs.r,
      testobs.r
    );
  }

  hits(walls) {
    return collideRectRect(
      this.x,
      this.y,
      this.r,
      this.r,
      walls.x,
      walls.y,
      walls.r,
      walls.r
    );
  }

  hits(collision) {
    return collideRectRect(
      this.x,
      this.y,
      this.r,
      this.r,
      collision.x,
      collision.y,
      collision.r,
      collision.r
    );
  }

  hits(collision2) {
    return collideRectRect(
      this.x,
      this.y,
      this.r,
      this.r,
      collision2.x,
      collision2.y,
      collision2.r,
      collision2.r
    );
  }

  hits(collision3) {
    return collideRectRect(
      this.x,
      this.y,
      this.r,
      this.r,
      collision3.x,
      collision3.y,
      collision3.r,
      collision3.r
    );
  }

  hits(collision4) {
    return collideRectRect(
      this.x,
      this.y,
      this.r,
      this.r,
      collision4.x,
      collision4.y,
      collision4.r,
      collision4.r
    );
  }

  hits(collision5) {
    return collideRectRect(
      this.x,
      this.y,
      this.r,
      this.r,
      collision5.x,
      collision5.y,
      collision5.r,
      collision5.r
    );
  }

  hits(collision6) {
    return collideRectRect(
      this.x,
      this.y,
      this.r,
      this.r,
      collision6.x,
      collision6.y,
      collision6.r,
      collision6.r
    );
  }

  hits(collision7) {
    return collideRectRect(
      this.x,
      this.y,
      this.r,
      this.r,
      collision7.x,
      collision7.y,
      collision7.r,
      collision7.r
    );
  }

  hits(collision8) {
    return collideRectRect(
      this.x,
      this.y,
      this.r,
      this.r,
      collision8.x,
      collision8.y,
      collision8.r,
      collision8.r
    );
  }

  hits(collision9) {
    return collideRectRect(
      this.x,
      this.y,
      this.r,
      this.r,
      collision9.x,
      collision9.y,
      collision9.r,
      collision9.r
    );
  }

  hits(wind) {
    return collideRectRect(
      this.x,
      this.y,
      this.r,
      this.r,
      wind.x,
      wind.y,
      wind.r,
      wind.r
    );
  }

  hits(cloud) {
    return collideRectRect(
      this.x,
      this.y,
      this.r,
      this.r,
      cloud.x,
      cloud.y,
      cloud.r,
      cloud.r
    );
  }

  hits(pit) {
    return collideRectRect(
      this.x,
      this.y,
      this.r,
      this.r,
      pit.x,
      pit.y,
      pit.r,
      pit.r
    );
  }
  
  hits(pit2) {
    return collideRectRect(
      this.x,
      this.y,
      this.r,
      this.r,
      pit2.x,
      pit2.y,
      pit2.r,
      pit2.r
    );
  }

  move() {
    this.y += this.vy;
    this.vy += this.gravity;
    this.y = constrain(this.y, 0, 250);
    this.x += this.vx;
    //this.x = constrain(this.x, 0, 350);
  }

  show() {
    image(tImg, this.x, this.y, this.r, this.r);
    //rect(this.x, this.y, this.r, this.r);
  }
}

class Walls {
  constructor() {
    this.r = 40;
    this.t = 100;
    this.x = character.x + 600;
    this.y = mouseY;
  }

  move() {
    this.x -= 10
  }

  show() {
    image(dImg, this.x, mouseY, this.r, this.t);
    //rect(this.x, this.y, this.r, this.r);
  }
}

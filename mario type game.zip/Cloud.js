class Cloud {
  constructor() {
    this.r = 70;
    this.t = 30;
    this.x = character.x + 600;
    this.y = 185;
  }

  move() {
    this.x -= 2;
  }

  show() {
    image(lImg, this.x, this.y, this.r, this.t);
    //rect(this.x, this.y, this.r, this.r);
  }
}
